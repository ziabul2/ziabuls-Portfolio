<?php
return array (
  'username' => 'ziabul1',
  'password_hash' => '$2y$10$M1LToP5.UKye78j1M16LYeNitF4XFCOjPXN24y7lS8MWLJRnDJYty',
  'session_lifetime' => 3600,
  'avatar' => '/cv/assets/ziabul islam - non bg.png',
  'display_name' => 'Ziabul islam',
  'email' => 'ziabulislam2222@gmail.com',
);
