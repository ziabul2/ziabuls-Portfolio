<?php
/**
 * Database Config - Managed by Admin Panel
 */

return array (
  'host' => 'localhost',
  'database' => 'ezyro_40986489_aboutblogs',
  'username' => 'root',
  'password' => '',
  'charset' => 'utf8mb4',
  'options' => 
  array (
    3 => 2,
    19 => 2,
    20 => false,
  ),
);
